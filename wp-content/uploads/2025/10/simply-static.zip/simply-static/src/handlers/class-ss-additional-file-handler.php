<?php

namespace Simply_Static;

class Additional_File_Handler extends Page_Handler {}